import './style.css';
import { initLenis } from './scripts/lenis.js';
import { initHeaderScroll } from './scripts/headerScroll.js';
import { initNav } from './scripts/nav.js';
import { initScrollReveal } from './scripts/scrollReveal.js';

const lenis = initLenis();

initHeaderScroll(lenis);
initNav(lenis);
initScrollReveal();
