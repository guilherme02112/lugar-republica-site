export function initHeaderScroll(lenis) {
  const header = document.querySelector('.site-header');
  if (!header) return;

  const SCROLL_THRESHOLD = 40;

  function updateHeader(scrollY) {
    if (scrollY > SCROLL_THRESHOLD) {
      header.classList.add('is-scrolled');
    } else {
      header.classList.remove('is-scrolled');
    }
  }

  if (lenis) {
    lenis.on('scroll', ({ scroll }) => updateHeader(scroll));
  } else {
    window.addEventListener('scroll', () => updateHeader(window.scrollY));
  }

  updateHeader(window.scrollY);
}
