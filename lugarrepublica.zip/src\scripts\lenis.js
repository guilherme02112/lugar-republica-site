import Lenis from 'lenis';

let lenisInstance = null;

export function initLenis() {
  lenisInstance = new Lenis({
    duration: 1.1,
    smoothWheel: true,
  });

  function raf(time) {
    lenisInstance.raf(time);
    requestAnimationFrame(raf);
  }

  requestAnimationFrame(raf);

  return lenisInstance;
}

export function getLenis() {
  return lenisInstance;
}
