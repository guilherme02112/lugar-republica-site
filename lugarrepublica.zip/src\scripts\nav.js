export function initNav(lenis) {
  const toggle = document.querySelector('.nav-toggle');
  const menuMobile = document.querySelector('.menu-mobile');
  const header = document.querySelector('.site-header');
  const anchorLinks = document.querySelectorAll('a[href^="#"]');

  function closeMobileMenu() {
    if (!menuMobile) return;
    menuMobile.classList.remove('is-open');
    document.body.style.overflow = '';
    toggle?.setAttribute('aria-expanded', 'false');
    toggle?.setAttribute('aria-label', 'Abrir menu');
  }

  function toggleMobileMenu() {
    if (!menuMobile) return;
    const isOpen = menuMobile.classList.toggle('is-open');
    document.body.style.overflow = isOpen ? 'hidden' : '';
    toggle?.setAttribute('aria-expanded', String(isOpen));
    toggle?.setAttribute('aria-label', isOpen ? 'Fechar menu' : 'Abrir menu');
  }

  toggle?.addEventListener('click', toggleMobileMenu);

  const headerHeight = header?.offsetHeight ?? 0;

  anchorLinks.forEach((link) => {
    link.addEventListener('click', (event) => {
      const href = link.getAttribute('href');
      if (!href || href === '#') return;

      const targetEl = document.querySelector(href);
      if (!targetEl) return;

      event.preventDefault();
      closeMobileMenu();

      if (lenis) {
        lenis.scrollTo(targetEl, { offset: -headerHeight });
      } else {
        targetEl.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
}
